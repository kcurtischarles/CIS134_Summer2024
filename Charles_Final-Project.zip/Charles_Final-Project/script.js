$(document).ready(function() {
    $("#contact-form").on("submit", function(event) {
        event.preventDefault();

        var email = $("#email").val();
        var message = $("#message").val();

        if (email && message) {
            alert("Form submitted!\n\nEmail: " + email + "\nMessage: " + message);
        } else {
            alert("Please fill in both fields.");
        }
    });
});
