$(document).ready(function()
{
    $("p").css("color","green");
    $("#para1").css("color","blue");
    $(".paraTwo").css("color","orange");
    $("#h2Hide").click(function()
        {
            $("#para2").toggle(); //previously was .hide      
        })
    $("#h2Show").click(function()
        {          
            $("#para2").show();        
        })
    $("#btnHide").click(function()
        {
            $("#para1").toggle();
        })
    
    $("#findOut").click(function(){
            $("#mainChar").html("<p>The main character couldn't go through with the task.</p>");
       
    });    
    
    $("#anchorGoogle").attr(
        {
            href: "https://www.google.com/",
            target: "_blank"
        });
    
    $("#btnAdd").click(function()
        {
        $("#addedContent").append("<p>Here is additional information</p>");
        });
    
    $("#btnPrompt").click(function(){
        var promptBtn = prompt("Please provide additional information");
        $("#promptInfo").append("<h2>" + promptBtn + "</h2>");
    });
  
    
    
});

